These are the components of the keyboard case.
The black line is the cutline.

